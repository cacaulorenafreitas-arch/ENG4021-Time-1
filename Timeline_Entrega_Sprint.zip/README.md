# Timeline
Protótipo funcional de gestão de tempo para estudantes da PUC-Rio. Projeto acadêmico independente, sem vínculo oficial com os sistemas da universidade.

Especificação consolidada: [System_Specifications.md](System_Specifications.md).
Registro mais recente: [Testes da sprint](docs/Registro_Testes_Sprint.md), com 63 testes automatizados e execução da interface desktop em ambiente isolado.

## Escopo desta sprint
- Cadastrar atividades com título, matéria opcional, prazo e prioridade.
- Editar atividades já cadastradas.
- Marcar uma atividade como concluída e reabri-la.
- Visualizar entregas em um calendário semanal, de segunda a domingo.
- Navegar entre semanas e retornar à semana atual.
- Salvar os dados no servidor, separados por navegador, sem cadastro ou login.
- Mostrar prazos vencidos e resumo de tarefas pendentes/concluídas.
- Navegar por Hoje, Agenda, Calendário, Tarefas, Progresso e Configurações.
- Buscar tarefas por título/disciplina e filtrar status, prioridade e disciplina.
- Acompanhar contagens e barras de progresso com os dados cadastrados.

A identidade foi revisada a partir do **Design System.pdf** do grupo. A avaliação original dos casos de uso e a atualização de escopo estão em [docs/verificacao_casos_de_uso.md](docs/verificacao_casos_de_uso.md). Cadastro e login foram retirados desta sprint a pedido do responsável pelo protótipo.

Planejamento automático, lembretes, integração com Moodle e gestão de grupos não fazem parte desta versão.

## Como usar
1. Abra o site. Não é necessário criar conta nem entrar no ChatGPT ou Supabase.
2. Clique em **Adicionar tarefa**, preencha os campos e clique em **Salvar tarefa**.
3. A entrega aparece no calendário e na lista de tarefas.
4. Clique no título para editar. Use a caixa de seleção para concluir ou reabrir.
5. Use as setas do calendário para mudar de semana; **Hoje** retorna à semana atual.
6. Recarregue a página: as tarefas continuam salvas.

Sem horário informado, o prazo vale até o fim da data escolhida. Datas e horários usam o fuso local do dispositivo. As datas de entrega não são blocos de estudo: o calendário mostra prazos, não agenda horários automaticamente.

As tarefas ficam no servidor; um cookie deste navegador permite acessá-las novamente. Não há sincronização entre dispositivos. Limpar os cookies, trocar de navegador ou encerrar uma janela anônima faz perder esse acesso; não apaga as tarefas do servidor. Pessoas que compartilham o mesmo navegador também compartilham esse planejamento. Use dados de demonstração, sem informações sensíveis.

## Tecnologia
- TypeScript e React, com Vinext/Vite.
- Componentes acessíveis de interface fornecidos pelo starter (Radix/Shadcn).
- API executada em Cloudflare Workers.
- Persistência em D1/SQLite e migrações geradas com Drizzle.
- Sessão anônima automática com cookie HttpOnly, Secure e SameSite=Lax; nenhum cadastro de conta ou senha.
- Testes automatizados com o executor de testes do Node.js.

A interface usa `/api/prototype/tasks`: um token aleatório de 256 bits identifica o navegador, e somente seu hash com prefixo próprio é usado como proprietário no banco. As gravações exigem origem igual à do site. O cookie não é acessível ao JavaScript nem retornado no JSON. O identificador de proprietário nunca vem do formulário. O cookie tem validade de até um ano, renovada ao carregar as tarefas; o navegador pode removê-lo antes.

A API antiga `/api/tasks` permanece protegida pelo cabeçalho de identidade inserido pela plataforma, sem uso na interface atual. Dados antigos de contas não foram apagados, migrados nem tornados públicos. Não exponha esse endpoint fora da plataforma sem um gateway de identidade confiável.

## Organização do código
- `app/page.tsx`: entrada direta da aplicação, sem consulta de conta.
- `app/timeline.tsx`: interface, formulário, navegação e calendário.
- `app/globals.css`: identidade visual e comportamento responsivo.
- `lib/planner.mjs`: validação, datas, ordenação e atrasos.
- `lib/timeline.mjs`: busca, filtros, agenda cronológica e progresso.
- `lib/task-api.mjs`: tratamento das solicitações e regras de acesso.
- `lib/prototype-api.mjs`: acesso sem login, isolamento entre navegadores e cookie de sessão.
- `db/task-store.mjs`: consultas parametrizadas por proprietário.
- `db/schema.ts` e `drizzle/`: estrutura e migrações do banco.
- `worker/index.ts`: entrada do servidor.
- `tests/`: testes executáveis.
- `docs/registro_testes.md`: resultados, limitações e roteiro manual.
- `docs/verificacao_casos_de_uso.md`: avaliação individual dos requisitos e do design.
- `docs/test-results.tap`: saída bruta da execução dos testes.

## Instalação e testes locais
Requer Node.js 22.13 ou superior e ambiente Linux/WSL para os scripts do projeto. A execução registrada utilizou Node.js 24.19.0.

```bash
npm ci
npm test
npx tsc --noEmit
```

`npm test` compila a aplicação e executa os testes. Os testes usam dados fictícios em SQLite isolado, nunca o banco do site publicado. A API é exercitada por requisições HTTP em memória e por uma chamada ao Worker compilado; isso não equivale a cliques no navegador.

A publicação deve usar a plataforma Sites e aplicar as migrações de `drizzle/`. Colocar os arquivos no GitHub não publica a aplicação. Esta versão não funciona apenas no GitHub Pages, pois depende de servidor e banco. O acesso publicado deve usar HTTPS para o cookie seguro.

## Entrega no GitHub
O repositório e a pasta de destino devem ser definidos pelo PO. O envio ao GitHub permanece pendente até que o destino e o acesso sejam fornecidos.

Para envio manual:
1. Extraia o pacote de código-fonte.
2. Abra a pasta da sprint definida pelo PO no repositório.
3. Use **Add file → Upload files**, envie o conteúdo extraído e confira a estrutura das pastas.
4. Inclua o código-fonte, testes, relatório, migrações e arquivos de configuração.
5. Não envie `node_modules/`, `dist/`, `.git/`, `.sites-runtime/`, `.wrangler/`, arquivos `.env` ou credenciais.
6. Faça o commit na branch combinada e abra um pull request para revisão do PO, se esse for o fluxo do grupo.

## Limites e próximos testes
A configuração consultada nesta revisão permite visitas públicas. O protótipo abre diretamente e permite cadastrar, editar e concluir tarefas sem login. O isolamento é por navegador, não por pessoa; este mecanismo não substitui contas numa versão final.

O registro em `docs/Registro_Testes_Sprint.md` documenta a execução atual e suas limitações. O fluxo principal foi exercitado no navegador desktop do ambiente de teste; ainda faltam cliques na produção, dispositivos móveis reais e usabilidade com alunos. As entrevistas fictícias anteriores não constituem validação real com usuários.

Para testes de interface no ambiente interno HTTP, existe um cookie separado habilitado somente pelo modo de desenvolvimento e pelo endereço exato de preview. A publicação mantém o cookie seguro e não aceita esse cookie de teste. O banco de teste deve ser inicializado com as migrações existentes; não aplicar dados de demonstração no banco de produção.

As fontes Manrope/Inter estão declaradas com o fallback Arial/Helvetica permitido pelo Design System; arquivos de fonte não estão incorporados. O calendário apresenta prazos de tarefas, sem duração nem alocação automática de horários.
