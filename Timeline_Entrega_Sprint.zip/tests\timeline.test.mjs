import assert from "node:assert/strict";
import test from "node:test";
import { filterTasks, groupTasksByDay, taskProgress, chronologicalTasks } from "../lib/timeline.mjs";

const tasks = [
  { id: "1", title: "Lista de Cálculo", subject: "Cálculo I", dueDate: "2026-09-09", dueTime: "14:00", priority: "high", completed: false },
  { id: "2", title: "Ler capítulo", subject: "Psicologia", dueDate: "2026-09-10", dueTime: "", priority: "medium", completed: true },
  { id: "3", title: "Revisar notas", subject: "Cálculo I", dueDate: "2026-09-09", dueTime: "18:00", priority: "low", completed: false },
];
test("T01 — busca por título ignora acentos, caixa e espaços externos", () => {
  assert.deepEqual(filterTasks(tasks, { query: " CALCULO " }).map(t => t.id), ["1", "3"]);
});
test("T02 — busca também encontra uma disciplina", () => {
  assert.deepEqual(filterTasks(tasks, { query: "psicologia" }).map(t => t.id), ["2"]);
});
test("T03 — filtra pendentes e concluídas", () => {
  assert.deepEqual(filterTasks(tasks, { status: "pending" }).map(t => t.id), ["1", "3"]);
  assert.deepEqual(filterTasks(tasks, { status: "completed" }).map(t => t.id), ["2"]);
});
test("T04 — combina filtros de disciplina, prioridade e status", () => {
  assert.deepEqual(filterTasks(tasks, { subject: "Cálculo I", priority: "high", status: "pending" }).map(t => t.id), ["1"]);
});
test("T05 — busca sem correspondências retorna lista vazia", () => {
  assert.deepEqual(filterTasks(tasks, { query: "maquete" }), []);
});
test("T06 — filtros não alteram dados nem ordem da entrada", () => {
  const snapshot = structuredClone(tasks);
  filterTasks(tasks, { priority: "medium" });
  assert.deepEqual(tasks, snapshot);
});
test("T07 — progresso de lista vazia é zero sem divisão inválida", () => {
  assert.deepEqual(taskProgress([]), { done: 0, total: 0, percent: 0 });
});
test("T08 — progresso usa apenas tarefas reais e arredonda a porcentagem", () => {
  assert.deepEqual(taskProgress(tasks), { done: 1, total: 3, percent: 33 });
});
test("T09 — reabrir tarefa atualiza o progresso", () => {
  assert.deepEqual(taskProgress(tasks.map(t => ({ ...t, completed: false }))), { done: 0, total: 3, percent: 0 });
});
test("T10 — agenda agrupa por data em ordem cronológica", () => {
  const groups = groupTasksByDay([...tasks].reverse());
  assert.deepEqual(groups.map(([day]) => day), ["2026-09-09", "2026-09-10"]);
  assert.deepEqual(groups[0][1].map(t => t.id), ["1", "3"]);
});
test("T11 — agenda vazia não inventa atividades", () => {
  assert.deepEqual(groupTasksByDay([]), []);
});
test("T12 — timeline mantém ordem horária mesmo após concluir tarefa", () => {
  const activities = [{ ...tasks[0], completed: true }, tasks[2]];
  assert.deepEqual(chronologicalTasks(activities).map(t => t.id), ["1", "3"]);
  assert.deepEqual(groupTasksByDay(activities)[0][1].map(t => t.id), ["1", "3"]);
});
