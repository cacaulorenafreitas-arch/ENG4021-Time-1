import { index, integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const tasks = sqliteTable("tasks", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  title: text("title").notNull(),
  subject: text("subject").notNull().default(""),
  dueDate: text("due_date").notNull(),
  dueTime: text("due_time").notNull().default(""),
  priority: text("priority", { enum: ["high", "medium", "low"] }).notNull(),

  category: text("category", {
    enum: ["homework", "exam", "project", "reminder", "personal", "other"],
  }).notNull().default("homework"),

  link: text("link").notNull().default(""),
  location: text("location").notNull().default(""),
  notes: text("notes").notNull().default(""),

  reminder: text("reminder", {
    enum: ["none", "at_time", "30_min", "1_hour", "1_day"],
  }).notNull().default("none"),

  completed: integer("completed", { mode: "boolean" }).notNull().default(false),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
}, (table) => [
  index("idx_tasks_owner_due").on(table.ownerId, table.dueDate),
]);