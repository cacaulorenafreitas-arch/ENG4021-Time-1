# Registro de testes da sprint — Timeline

Data: 16/09/2026 (UTC). Escopo: acesso sem login, tarefas, calendário e documentação da entrega.

## Resultado resumido

- **63 testes automatizados aprovados**, zero falhas, cancelamentos ou testes ignorados.
- Compilação de produção e verificação TypeScript concluídas sem erros.
- Fluxo principal executado por interação real com a interface em Chrome desktop, no ambiente de teste isolado.
- Quatro capturas da execução anexadas em `evidencias/`.
- Não foram realizados cliques no endereço de produção nem testes em celular físico. Não declarar essas etapas como concluídas.

O teste de interface foi conduzido por agente com cliques e teclado no navegador, não por um aluno participante de teste de usabilidade. Ele complementa os testes automatizados de regras/API, mas não substitui validação do PO, do professor ou dos usuários.

## Ambiente e dados

Código do mesmo projeto que é publicado, servido em modo de desenvolvimento. Banco D1 local de teste, separado do banco publicado, inicializado com a migração existente. Nenhuma tarefa de produção foi criada, editada ou apagada nesta verificação.

O navegador exibiu 15/09 enquanto o registro usa 16/09 UTC, devido ao fuso. A aplicação usa a data local do dispositivo. Largura útil observada: 1.348 px; largura de rolagem: 1.348 px, sem excedente horizontal nessa tela desktop.

Massa fictícia criada pela interface: “Teste — Lista de Cálculo”, disciplina “Cálculo I”, data inicial 15/09/2026, sem horário e prioridade alta. Na edição: “Teste — Revisar Cálculo”, data 15/10/2026 e prioridade baixa. Essa tarefa foi concluída e reaberta. Os dados permaneceram apenas no ambiente local de teste.

## Ajustes de preparação e ocorrências

1. O banco local estava vazio, sem tabelas. O carregamento mostrou erro recuperável e desabilitou a criação. Foi aplicada a migração já existente apenas nesse banco; a tentativa seguinte carregou a lista vazia normalmente.
2. O ambiente interno usa HTTP, incompatível com o cookie seguro da publicação HTTPS. O formulário mostrou a mensagem de cookies e preservou título e disciplina, sem afirmar que houve gravação.
3. Foi adicionada configuração estritamente de desenvolvimento: cookie e namespace próprios para o endereço interno de teste. A compilação publicada continua usando `__Host-`, `Secure`, `HttpOnly` e `SameSite=Lax`. Não foi afrouxada a proteção da produção. G13–G15 verificam os limites da configuração.
4. O preenchimento automático do campo nativo de data não se confirmou no estado da interface em uma tentativa; a edição foi repetida por teclado, confirmada no calendário e após recarga. Não é evidência de falha no uso manual.
5. Ao concluir, a ferramenta de teste perdeu o seletor antigo porque o nome acessível mudou de “Concluir” para “Reabrir”. A inspeção seguinte confirmou a caixa marcada, o status Concluída e o progresso de 100%; não foi repetida a ação indevidamente.

## Testes executados pela interface

| ID | Ação e resultado observado | Resultado |
| --- | --- | --- |
| UI01 | Abrir o protótipo: tela Hoje acessível, sem formulário ou botão de login. | Passou |
| UI02 | Salvar sem título: mensagem “Informe uma atividade com até 120 caracteres.”; diálogo aberto. | Passou |
| UI03 | Criar tarefa válida: confirmação, card, disciplina, prioridade alta e contagem de uma pendência. | Passou |
| UI04 | Editar título, data por teclado e prioridade: confirmação, mesmos dados alterados na coleção. | Passou |
| UI05 | Abrir Calendário após edição: semana 12–18/10, dia 15 selecionado e tarefa com prioridade baixa. | Passou |
| UI06 | Concluir no calendário: checkbox marcado, rótulo Reabrir, status Concluída e 1 de 1 concluída na semana. | Passou |
| UI07 | Abrir Progresso: percentual geral 100%, uma concluída e zero pendentes. | Passou |
| UI08 | Reabrir na lista: confirmação “Tarefa reaberta”, retorno ao status Pendente. | Passou |
| UI09 | Recarregar página: tarefa permanece com título editado, prazo de outubro, prioridade baixa e status pendente. | Passou |
| UI10 | Buscar “calculo” sem acento: encontra a tarefa com Cálculo no título/disciplina. | Passou |
| UI11 | Filtrar Concluídas quando a tarefa está pendente: estado sem resultados; Limpar filtros restaura a lista. | Passou |
| UI12 | Próxima semana muda de 14–20/09 para 21–27/09; Hoje retorna à semana do dia local. | Passou |
| UI13 | Selecionar 16/09 e Adicionar neste dia: data do formulário preenchida com 2026-09-16. | Passou |
| UI14 | Escape fecha o diálogo sem cadastrar tarefa; navegação permanece utilizável. | Passou |
| UI15 | Notificações explica que lembretes não existem; Ver minha agenda abre Agenda. | Passou |
| UI16 | Configurações informa os limites de cookies/navegador e não oferece login ou logout. | Passou |
| UI17 | Inspeção desktop de Hoje: logo, menu e conteúdo legíveis; largura do documento igual à área útil. | Passou no tamanho testado |

## Evidências visuais

As imagens abaixo são capturas da implementação em teste, **não os PNGs originais do protótipo visual** do grupo. Não demonstram responsividade em celular nem execução na produção.

### Tela Hoje após cadastrar

![Hoje com a tarefa de teste](evidencias/timeline-teste-hoje-20260916.jpg)

### Calendário após editar prazo e prioridade

![Calendário com o novo prazo](evidencias/timeline-teste-calendario-20260916.jpg)

### Progresso após concluir

![Progresso de 100% após concluir uma tarefa](evidencias/timeline-teste-progresso-20260916.jpg)

### Formulário na data selecionada

![Formulário com data do calendário](evidencias/timeline-teste-formulario-20260916.jpg)

## Testes automatizados

Execução após build: `node --test tests/*.test.mjs`. Verificação de tipos: `node_modules/.bin/tsc --noEmit`.

- U01–U15: campos, limites, datas, horários, prioridades, semanas, ordenação e atraso.
- I01–I17: regressão da API antiga protegida, persistência, isolamento, entradas inválidas e Worker compilado; I17 também exercita o fluxo sem login do Worker.
- G01–G15: sessão anônima, CRUD sem conta, renovação do cookie, isolamento entre navegadores, dados antigos protegidos, origem, validação, falhas de banco, hash do token, persistência e separação entre cookies de desenvolvimento/produção.
- T01–T12: busca, filtros, progresso, agrupamento e ordem cronológica.
- Quatro testes de componentes/utilitários: CSS, progresso acessível, estilos do gráfico herdado e renderização da sidebar. Isso não implica que todos os componentes herdados são recursos do produto.

Saída integral: [test-results-sprint-20260916.txt](test-results-sprint-20260916.txt). Os avisos de armazenamento indisponível são esperados nos testes que simulam falha de banco. Não houve teste de carga, auditoria integral de segurança ou validação por usuários reais.

## Verificações que ainda dependem do grupo

- [ ] No site publicado, criar, editar, concluir, reabrir e recarregar em um computador real.
- [ ] Repetir no celular, incluindo teclado aberto, rolagem, seletor de data, menu inferior e formulário.
- [ ] Conferir isolamento em outro navegador, sem compartilhar cookies. A lógica foi testada automaticamente, mas não em dois dispositivos físicos.
- [ ] Revisar fluxo por teclado completo, leitor de tela, ampliação de texto e contraste de todos os estados.
- [ ] Confrontar as telas com os PNGs originais, fluxograma e modelo do grupo, se existentes.
- [ ] Validar com PO/professor o escopo sem login e o formato da entrega.
- [ ] Enviar os arquivos ao repositório GitHub do grupo.

Essas pendências não devem ser marcadas como aprovadas somente porque o build e os testes automatizados passaram.
