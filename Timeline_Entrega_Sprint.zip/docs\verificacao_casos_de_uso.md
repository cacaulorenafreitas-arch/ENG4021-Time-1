# Verificação dos requisitos e casos de uso — Timeline

## Atualização de escopo — 15/09/2026

Por solicitação do responsável pelo protótipo, **C01/RF01 (cadastro e login) ficam fora do escopo desta sprint**. Isso é uma alteração de escopo, não uma classificação de requisito como atendido. A aplicação abre diretamente, com cadastro, edição, conclusão/reabertura de tarefas e calendário semanal. Não requer conta do ChatGPT ou Supabase.

As tarefas continuam persistidas em D1, isoladas por uma sessão anônima do navegador. Um cookie seguro permite retomar o planejamento no mesmo navegador; não há sincronização entre dispositivos. Limpar o cookie faz perder o acesso, sem apagar os registros. O compartilhamento do navegador também compartilha as tarefas. Dados privados da versão anterior não foram expostos nem migrados.

A área Perfil foi substituída por Ajustes/Configurações, com explicação dessas limitações. A identidade visual e os demais recursos foram mantidos. O registro de testes documenta a verificação desta mudança. A avaliação abaixo é o histórico de 09/09/2026; suas referências a login e totais não representam o novo escopo.

## Avaliação histórica — antes da retirada do login

Data: 09/09/2026 (UTC).
Referências: **Requisitos e Casos de Uso.pdf** e **Design System.pdf**, fornecidos pelo grupo.
Objeto: código do protótipo existente, interface revisada e testes descritos no registro.

## Resultado

**O protótipo atende ao núcleo de tarefas da sprint, mas não atende integralmente ao conjunto de casos de uso do documento.**

Dos 12 casos de uso, **5 estão parcialmente atendidos e 7 não estão implementados**. Nenhum foi classificado como integralmente atendido, pois foram considerados todos os critérios de aceitação de cada caso, e não apenas a presença de uma tela semelhante.

O cadastro, a edição, a conclusão/reabertura e a persistência de tarefas foram verificados por testes automatizados da API e do banco isolado. A navegação e a validação do formulário foram exercitadas no navegador em uma sessão sem login. O ciclo autenticado completo no navegador permanece pendente.

“Parcial” significa que existe uma parte do fluxo solicitado, mas ainda falta comportamento obrigatório. A classificação abaixo se refere à implementação, não à validação do problema com alunos.

## Casos de uso

### C01 — Cadastrar e acessar a conta: parcialmente atendido

Existe autenticação fornecida pela plataforma e os dados são vinculados a uma conta. A revisão acrescentou uma entrada explícita **Entrar com ChatGPT** para visitantes sem login, além de acesso ao perfil e saída da conta.

Evidência: a API rejeita solicitações sem identidade; testes de isolamento entre contas e de persistência foram aprovados. O navegador mostrou o aviso de acesso e impediu salvar sem login.

Falta: cadastro próprio com os dados previstos pelo documento, caso isso seja obrigatório, e execução do ciclo de login e retorno pelo navegador. A aceitação de autenticação externa como substituto do cadastro deve ser decidida pelo PO/professor.

### C02 — Cadastrar grade de aulas: não implementado

Não há cadastro de disciplinas com dias da semana, horários de início e fim ou recorrência. O campo “Disciplina” da tarefa é apenas um texto e não constitui uma grade de aulas.

Falta: modelo de disciplinas/aulas, formulário de grade, validação de horários e uso da grade no planejamento semanal.

### C03 — Cadastrar atividades acadêmicas: parcialmente atendido

O formulário permite nome, disciplina opcional, data, horário opcional e prioridade manual. Permite editar os mesmos campos.

Evidência: testes I03, I04, I06, U01–U08; no navegador, título obrigatório, seleção de prioridade e preenchimento automático da data escolhida foram conferidos.

Falta: dificuldade, importância e peso na nota como campos próprios, além das regras que consumiriam esses dados. Não se deve tratar a prioridade manual como equivalente a todos esses atributos.

### C04 — Cadastrar compromissos pessoais: não implementado

É possível digitar um compromisso no título de uma tarefa, mas não há um fluxo próprio com início/fim, duração e bloqueio de disponibilidade.

Falta: cadastro de compromissos pessoais, integração com a agenda e reserva de horários para o planejamento automático.

### C05 — Definir/sugerir prioridades: parcialmente atendido

Há prioridade alta, média ou baixa, escolhida pelo usuário. A lista coloca pendentes antes de concluídas e usa prazo, horário e prioridade como critérios de ordenação.

Falta: sugestão baseada em dificuldade, duração estimada, importância e peso na nota. A interface agora explica que a prioridade é definida pelo usuário.

### C06 — Gerar planejamento semanal: parcialmente atendido

Há calendário semanal de prazos e agenda cronológica. É possível navegar entre semanas, selecionar uma data e ver suas tarefas. Isso cobre a visualização de parte do resultado esperado.

Falta: geração do plano, alocação em intervalos livres e consideração de grade de aulas, compromissos e duração. O calendário exibe datas de entrega; não agenda sessões de estudo.

### C07 — Receber lembretes: não implementado

Não há agendamento ou envio de lembretes de prazos ou informações acadêmicas ausentes.

A tela de notificações informa essa limitação e direciona à agenda. Mensagens como “Tarefa salva” e indicadores de prazo passado não contam como lembretes automáticos.

### C08 — Identificar conflitos de horários: não implementado

Não há comparação de intervalos nem alerta de sobreposição. Tarefas com o mesmo horário não são impedidas.

Falta: representar intervalos, comparar aulas/compromissos/tarefas e evitar conflitos no plano gerado.

### C09 — Identificar sobrecarga: não implementado

As contagens de tarefas e o progresso mostram dados descritivos, mas não antecipam concentração excessiva de entregas ou provas.

Falta: critério de capacidade/sobrecarga, análise antecipada e alerta associado ao período afetado.

### C10 — Replanejar atividades não concluídas: parcialmente atendido

É possível concluir, reabrir e alterar manualmente o prazo de uma tarefa.

Evidência: I04 e I05 verificam edição e mudança de status; T09 verifica a atualização do progresso.

Falta: detectar a necessidade de replanejamento, sugerir novos horários livres e apresentar um plano atualizado sem conflitos.

### C11 — Aproveitar pequenos intervalos livres: não implementado

Não há cálculo de disponibilidade nem recomendação de atividades compatíveis com um intervalo.

Falta: grade e compromissos, estimativas de duração e verificação de que a atividade termina antes do próximo compromisso.

### C12 — Estimar duração de atividades: não implementado

Não há campo ou cálculo de duração estimada.

Falta: dados de tipo, dificuldade e tamanho da atividade, estimativa explicável e uso dessa estimativa no planejamento.

## Requisitos funcionais

- **RF01 — Conta e acesso: parcial.** Acesso pela plataforma, com entrada explícita; cadastro próprio ausente.
- **RF02 — Grade de aulas: não atendido.**
- **RF03 — Atividades acadêmicas: parcial.** Cadastro genérico; não diferencia tipos de atividade em campo próprio.
- **RF04 — Compromissos pessoais: não atendido.**
- **RF05 — Características da atividade: parcial.** Prazo, disciplina e prioridade presentes; demais atributos ausentes.
- **RF06 — Sugestão de prioridades: parcial.** Ordenação básica e prioridade manual; não há sugestão multicritério.
- **RF07 — Planejamento semanal automático: não atendido.**
- **RF08 — Agenda/calendário semanal: parcial.** Tarefas visíveis; aulas e compromissos pessoais não estão representados como entidades próprias.
- **RF09 — Notificações/lembretes: não atendido.**
- **RF10 — Conflitos de horário: não atendido.**
- **RF11 — Alertas de sobrecarga: não atendido.**
- **RF12 — Concluir/não concluir: atendido na implementação e nos testes da API.**
- **RF13 — Sugestão de replanejamento: não atendido.** Apenas edição manual disponível.
- **RF14 — Sugestão para intervalos curtos: não atendido.**
- **RF15 — Estimativa de duração: não atendido.**

RF07 permanece “não atendido” porque exige especificamente geração automática. C06 foi classificado como “parcial” porque também inclui a visualização do resultado, que existe apenas para prazos.

## Requisitos não funcionais

- **RNF01 — Interface intuitiva:** parcialmente verificado por inspeção. Menu com rótulos, estados vazios, instruções e feedback presentes. Falta teste de usabilidade com alunos.
- **RNF02 — Poucas etapas:** o cadastro usa abertura do formulário, preenchimento e salvamento. A autenticação inicial é uma etapa adicional. Falta medir esforço/tempo com usuários.
- **RNF03 — Organização clara:** aplicada separação entre Hoje, Agenda, Calendário, Tarefas e Progresso, com títulos e legendas. Verificação visual em desktop concluída.
- **RNF04 — Consistência das visualizações:** listas, calendário e contadores usam a mesma coleção de tarefas. Testes cobrem filtragem, ordenação, agrupamento e progresso; falta conferir todas as transições com dados autenticados no navegador.
- **RNF05 — Legibilidade:** paleta e hierarquia revisadas, texto de estado além das cores e foco de teclado visível. Contrastes principais calculados: Ink/branco 15,59:1; Slate/Background 5,41:1; branco/Deep Lavender 5,79:1. Branco/Lavender Blue é 3,79:1, por isso esse botão usa texto grande e em negrito; botões com texto menor usam Deep Lavender. Não houve auditoria completa de acessibilidade.
- **RNF06 — Persistência segura:** testes verificam identidade obrigatória, isolamento de contas, consultas parametrizadas e permanência após reabrir o banco. Dependência da autenticação da plataforma mantida. Não equivale a auditoria de segurança de produção ou teste de restauração de backup.
- **RNF07 — Tempo de resposta:** chamadas locais dos testes concluídas; não há meta quantitativa no documento nem teste de carga/latência da produção. Não validado integralmente.
- **RNF08 — Mobile e desktop:** CSS responsivo implementado, com menu inferior no mobile. Desktop verificado em navegador. Dispositivo móvel real e múltiplos navegadores ainda precisam de teste.

## Adequação ao Design System

Implementado:
- Nome **Timeline**, slogan e logo original extraído do PDF, com proporções preservadas.
- Cores Lavender Blue, Deep Lavender, Soft/Light Lavender, Ink, Slate, Background, Surface e Border.
- Fontes declaradas Manrope nos títulos e Inter na interface, com fallback Arial/Helvetica permitido pelo documento. Os arquivos dessas fontes não estão incorporados; a fonte efetiva depende da disponibilidade no dispositivo.
- Fundo claro, bordas discretas, superfícies brancas e sombras leves.
- Menu desktop: Hoje, Agenda, Calendário, Tarefas, Progresso e Configurações.
- Menu mobile: Hoje, Agenda, Adicionar, Calendário e Perfil. Tarefas e Progresso também são acessíveis pelos atalhos do perfil.
- Tela Hoje com resumo, timeline diária, próximo prazo e progresso.
- Calendário semanal com pontos coloridos e informações completas da data selecionada.
- Busca por nome/disciplina; filtros de status, prioridade e disciplina.
- Cards com conclusão, título, disciplina, prazo, prioridade e status por texto.
- Progresso numérico e barra com dados reais, inclusive no estado vazio.
- Formulário, mensagens e estados vazios com linguagem breve e calma.
- Componentes de diálogo, seleção, checkbox, barra de progresso e sidebar reaproveitados.

Limites: o PDF descreve um sistema visual e padrões de telas, não um conjunto completo de telas finais com medidas exatas. A revisão aplica essas diretrizes; não é uma reprodução pixel a pixel. Recursos avançados descritos nas telas continuam dependentes das implementações ausentes acima.

## Próximas entregas sugeridas ao PO

1. Definir a aceitação de login externo para C01 e executar o roteiro autenticado.
2. Implementar grade de aulas e compromissos pessoais (C02/C04).
3. Acrescentar atributos e estimativa de duração (C03/C12).
4. Implementar prioridade sugerida, geração do plano e conflitos (C05/C06/C08).
5. Acrescentar sobrecarga, replanejamento e intervalos curtos (C09/C10/C11).
6. Implementar lembretes (C07) e validar o produto com alunos reais.

O registro de testes acompanha este relatório em **registro_testes.md**. As entrevistas fictícias fornecidas anteriormente servem como material de simulação; não comprovam validação com usuários reais.
