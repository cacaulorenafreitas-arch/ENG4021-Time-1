"use client";

import { useEffect, useMemo, useState } from "react";
import { ArrowRight, Bell, CalendarDays, ChartNoAxesColumnIncreasing, Check, CheckCheck, ChevronLeft, ChevronRight, Clock3, ListTodo, LoaderCircle, Plus, Search, Settings2, ShieldCheck, Sun, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider } from "@/components/ui/sidebar";
import { dateKey, weekDays, formatWeek, sortTasks, isOverdue, validateTask, priorityLabels } from "@/lib/planner.mjs";
import { filterTasks, taskProgress, groupTasksByDay, chronologicalTasks } from "@/lib/timeline.mjs";

type Priority = keyof typeof priorityLabels;
type Task = { id: string; title: string; subject: string; dueDate: string; dueTime: string; priority: Priority; completed: boolean };
type Draft = Omit<Task, "id" | "completed">;
type View = "today" | "agenda" | "calendar" | "tasks" | "progress" | "settings";
type Access = "loading" | "ready" | "error";
const navigation = [
  { id: "today", label: "Hoje", icon: Sun },
  { id: "agenda", label: "Agenda", icon: Clock3 },
  { id: "calendar", label: "Calendário", icon: CalendarDays },
  { id: "tasks", label: "Tarefas", icon: ListTodo },
  { id: "progress", label: "Progresso", icon: ChartNoAxesColumnIncreasing },
  { id: "settings", label: "Configurações", icon: Settings2 },
] as const;
const weekdays = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"];
const emptyDraft = (day: string): Draft => ({ title: "", subject: "", dueDate: day, dueTime: "", priority: "medium" });
const formatDay = (day: string, long = false) => day ? new Intl.DateTimeFormat("pt-BR", { ...(long ? { weekday: "long" as const } : {}), day: "numeric", month: long ? "long" : "short" }).format(new Date(day + "T12:00:00")) : "";

export default function Timeline() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [now, setNow] = useState<Date | null>(null);
  const [anchor, setAnchor] = useState("");
  const [selectedDay, setSelectedDay] = useState("");
  const [view, setView] = useState<View>("today");
  const [access, setAccess] = useState<Access>("loading");
  const [notice, setNotice] = useState("");
  const [noticeError, setNoticeError] = useState(false);
  const [open, setOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);
  const [draft, setDraft] = useState<Draft>(emptyDraft(""));
  const [formError, setFormError] = useState("");
  const [saving, setSaving] = useState(false);
  const [busy, setBusy] = useState<string[]>([]);
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const [priority, setPriority] = useState("all");
  const [subject, setSubject] = useState("all");
  const today = now ? dateKey(now) : "";
  const days: string[] = useMemo(() => anchor ? weekDays(anchor) : [], [anchor]);
  const todayTasks: Task[] = chronologicalTasks(tasks.filter(t => t.dueDate === today));
  const weekTasks = tasks.filter(t => days.includes(t.dueDate));
  const todayProgress = taskProgress(todayTasks);
  const weekProgress = taskProgress(weekTasks);
  const allProgress = taskProgress(tasks);
  const pending: Task[] = sortTasks(tasks.filter(t => !t.completed));
  const visibleTasks: Task[] = useMemo(() => filterTasks(tasks, { query, status, priority, subject }), [tasks, query, status, priority, subject]);
  const subjects = [...new Set(tasks.map(t => t.subject).filter(Boolean))].sort((a, b) => a.localeCompare(b, "pt-BR"));
  const pageTitle = navigation.find(item => item.id === view)?.label || "Hoje";
  const nextTask = pending.find(task => now && !isOverdue(task, now));
  const canWrite = access === "ready";

  async function load() {
    setAccess("loading");
    try {
      const response = await fetch("/api/prototype/tasks", { cache: "no-store" });
      const data = await response.json() as { tasks: Task[]; error?: string };
      if (!response.ok) throw new Error(data.error);
      setTasks(data.tasks); setAccess("ready");
    } catch { setAccess("error"); }
  }
  useEffect(() => {
    const current = new Date(); const day = dateKey(current);
    setNow(current); setAnchor(day); setSelectedDay(day); void load();
    const timer = window.setInterval(() => setNow(new Date()), 60000);
    return () => window.clearInterval(timer);
  }, []);

  function navigate(next: View) { setView(next); setQuery(""); setStatus("all"); setPriority("all"); setSubject("all"); }
  function begin(task?: Task, day?: string) {
    setEditing(task || null); setFormError(""); setNotice("");
    setDraft(task ? { title: task.title, subject: task.subject, dueDate: task.dueDate, dueTime: task.dueTime, priority: task.priority } : emptyDraft(day || today));
    setOpen(true);
  }
  async function save(event: React.FormEvent) {
    event.preventDefault(); if (saving) return;
    const validation = validateTask(draft);
    if (!validation.ok) { setFormError(validation.error || "Confira os campos."); return; }
    if (!canWrite) { setFormError("Aguarde o carregamento das tarefas e tente novamente."); return; }
    setSaving(true); setFormError("");
    try {
      const response = await fetch(editing ? "/api/prototype/tasks/" + editing.id : "/api/prototype/tasks", {
        method: editing ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(validation.value),
      });
      const data = await response.json() as { task: Task; error?: string };
      if (!response.ok) throw new Error(data.error || "Não foi possível salvar. Tente novamente.");
      setTasks(current => editing ? current.map(t => t.id === editing.id ? data.task : t) : [...current, data.task]);
      setAnchor(data.task.dueDate); setSelectedDay(data.task.dueDate);
      setNoticeError(false); setNotice(editing ? "Tarefa atualizada." : "Tarefa adicionada. Um passo de cada vez."); setOpen(false);
    } catch (error) { setFormError(error instanceof Error ? error.message : "Não foi possível salvar. Seus dados continuam no formulário."); }
    finally { setSaving(false); }
  }
  async function toggle(task: Task) {
    if (busy.includes(task.id) || !canWrite) return;
    setBusy(ids => [...ids, task.id]); setNotice("");
    try {
      const response = await fetch("/api/prototype/tasks/" + task.id, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ completed: !task.completed }) });
      const data = await response.json() as { task: Task; error?: string };
      if (!response.ok) throw new Error(data.error || "Não foi possível atualizar a tarefa.");
      setTasks(current => current.map(t => t.id === task.id ? data.task : t));
      setNoticeError(false); setNotice(task.completed ? "Tarefa reaberta. Você pode ajustar o prazo." : "Tarefa concluída. Seu progresso conta.");
    } catch (error) { setNoticeError(true); setNotice(error instanceof Error ? error.message : "Não foi possível atualizar. Tente novamente."); }
    finally { setBusy(ids => ids.filter(id => id !== task.id)); }
  }
  function moveWeek(direction: number) {
    if (!anchor) return;
    const date = new Date(anchor + "T12:00:00"); date.setDate(date.getDate() + direction * 7);
    const day = dateKey(date); setAnchor(day); setSelectedDay(day);
  }
  const newTaskButton = (label = "Adicionar tarefa") => <Button className="primary-button" onClick={() => begin()} disabled={access === "loading" || access === "error"}><Plus size={18} aria-hidden="true" />{label}</Button>;
  function empty(title = "Um espaço para se organizar", description = "Adicione uma tarefa para acompanhar seus próximos passos.") {
    return <div className="empty-state"><span className="empty-icon"><ListTodo size={27} aria-hidden="true" /></span><h3>{title}</h3><p>{description}</p>{newTaskButton("Adicionar uma tarefa")}</div>;
  }
  function taskItem(task: Task) {
    const late = now && isOverdue(task, now);
    return <article key={task.id} className={"task-card" + (task.completed ? " is-complete" : "")}>
      <Checkbox className="task-checkbox" checked={task.completed} disabled={busy.includes(task.id) || !canWrite} onCheckedChange={() => void toggle(task)} aria-label={(task.completed ? "Reabrir: " : "Concluir: ") + task.title} />
      <div className="task-copy"><button className="task-title" onClick={() => begin(task)} disabled={busy.includes(task.id)} aria-label={"Editar: " + task.title}>{task.title}</button><p>{task.subject || "Sem disciplina"}<span aria-hidden="true"> · </span>{formatDay(task.dueDate)}{task.dueTime && " · " + task.dueTime}</p></div>
      <div className="task-tags"><span className={"priority-badge " + task.priority}>Prioridade {priorityLabels[task.priority].toLowerCase()}</span>{task.completed ? <span className="status-tag done"><Check size={13} aria-hidden="true" />Concluída</span> : late ? <span className="status-tag late">Prazo passado</span> : <span className="status-tag">Pendente</span>}</div>
    </article>;
  }
  function weekControls() {
    return <div className="week-controls"><Button variant="outline" size="icon" aria-label="Semana anterior" onClick={() => moveWeek(-1)} disabled={!anchor}><ChevronLeft size={18} /></Button><Button variant="outline" onClick={() => { setAnchor(today); setSelectedDay(today); }}>Hoje</Button><Button variant="outline" size="icon" aria-label="Próxima semana" onClick={() => moveWeek(1)} disabled={!anchor}><ChevronRight size={18} /></Button></div>;
  }
  function weekPicker() {
    return <div className="week-picker" aria-label="Dias da semana">{days.map((day, index) => {
      const dayTasks = tasks.filter(task => task.dueDate === day);
      return <button key={day} className={"week-day" + (day === selectedDay ? " selected" : "") + (day === today ? " current-day" : "")} onClick={() => setSelectedDay(day)} aria-pressed={day === selectedDay} aria-label={formatDay(day, true) + ": " + dayTasks.length + " tarefas"}>
        <span>{weekdays[index]}</span><strong aria-current={day === today ? "date" : undefined}>{Number(day.slice(8))}</strong><span className="day-dots" aria-hidden="true">{dayTasks.slice(0, 3).map(task => <i key={task.id} className={task.completed ? "done-dot" : "dot-" + task.priority} />)}{dayTasks.length > 3 && <small>+</small>}</span>
      </button>;
    })}</div>;
  }
  function filterControl(label: string, value: string, onChange: (value: string) => void, items: [string, string][]) {
    return <Select value={value} onValueChange={onChange}><SelectTrigger aria-label={label} className="filter-select"><SelectValue /></SelectTrigger><SelectContent>{items.map(([key, text]) => <SelectItem key={key} value={key}>{text}</SelectItem>)}</SelectContent></Select>;
  }
  function settingsPanel() {
    return <section className="panel account-panel"><div className="account-icon"><Settings2 size={26} /></div><h2>Seu planejamento, sem cadastro</h2><p>As tarefas são salvas no servidor e ficam acessíveis por este navegador, usando um cookie. Não há sincronização entre dispositivos. Ao apagar os cookies ou encerrar uma janela anônima, você perde o acesso a essas tarefas. Quem usar este mesmo navegador poderá vê-las.</p><dl className="settings-list"><div><dt>Versão</dt><dd>Protótipo sem login</dd></div><div><dt>Acesso às tarefas</dt><dd>Vinculado a este navegador</dd></div><div><dt>Idioma</dt><dd>Português (Brasil)</dd></div><div><dt>Horários</dt><dd>Fuso local do dispositivo</dd></div><div><dt>Semana</dt><dd>Segunda a domingo</dd></div><div><dt>Lembretes automáticos</dt><dd>Ainda não disponíveis</dd></div></dl><div className="profile-shortcuts"><Button variant="outline" onClick={() => navigate("tasks")}>Minhas tarefas</Button><Button variant="outline" onClick={() => navigate("progress")}>Meu progresso</Button></div></section>;
  }

  return <SidebarProvider className="timeline-app">
    <a className="skip-link" href="#main-content">Pular para o conteúdo</a>
    <Sidebar collapsible="none" className="timeline-sidebar">
      <SidebarHeader className="sidebar-brand"><a href="/" aria-label="Timeline, início"><img src="/brand/timeline-logo.png" width="313" height="129" alt="Timeline. Plan today. Move at your pace." /></a></SidebarHeader>
      <SidebarContent className="sidebar-navigation"><span className="eyebrow">SEU ESPAÇO</span><nav aria-label="Navegação principal"><SidebarMenu>{navigation.map(item => <SidebarMenuItem key={item.id}><SidebarMenuButton isActive={view === item.id} className="nav-button" onClick={() => navigate(item.id)} aria-current={view === item.id ? "page" : undefined}><item.icon size={20} aria-hidden="true" /><span>{item.label}</span>{item.id === "tasks" && !!pending.length && <span className="nav-count">{pending.length}</span>}</SidebarMenuButton></SidebarMenuItem>)}</SidebarMenu></nav></SidebarContent>
      <SidebarFooter className="sidebar-footer"><div className="pace-note"><span className="pace-mark"><Sun size={21} aria-hidden="true" /></span><strong>No seu ritmo.</strong><p>Pequenos passos também<br />fazem o dia avançar.</p></div><button className="profile-button" onClick={() => navigate("settings")}><span className="avatar"><Settings2 size={19} /></span><span><strong>Seu planejamento</strong><small>Sem cadastro</small></span><Settings2 size={17} aria-hidden="true" /></button></SidebarFooter>
    </Sidebar>
    <div className="main-shell">
      <header className="topbar"><div className="topbar-title"><img className="mobile-symbol" src="/brand/timeline-symbol.png" width="234" height="214" alt="Timeline" /><span>{pageTitle}</span><span className="header-divider" /><span className="header-date">{formatDay(today, true)}</span></div><div className="header-tools"><div className="search-box"><Search size={17} aria-hidden="true" /><Input aria-label="Buscar tarefas" placeholder="Buscar tarefas" value={query} onChange={event => { setQuery(event.target.value); setView("tasks"); setStatus("all"); setPriority("all"); setSubject("all"); }} /></div><Button variant="ghost" size="icon" aria-label="Notificações" onClick={() => setNotificationsOpen(true)}><Bell size={20} /></Button><Button variant="ghost" size="icon" className="header-avatar" aria-label="Abrir configurações" onClick={() => navigate("settings")}><Settings2 size={18} /></Button></div></header>
      <main id="main-content" className="workspace" tabIndex={-1}>
        <section className="page-heading"><div><span className="eyebrow">{view === "today" ? "UM DIA DE CADA VEZ" : "SEU PLANEJAMENTO"}</span><h1>{view === "today" ? "Seu dia, no seu ritmo." : pageTitle}</h1><p>{({ today: "Abra espaço para o que importa. Comece pelo próximo passo.", agenda: "Seus prazos em ordem, com espaço para ajustar o caminho.", calendar: "Uma visão leve da semana. Selecione um dia para ver suas tarefas.", tasks: "Tudo o que você precisa fazer, em um só lugar.", progress: "Cada tarefa concluída é um passo. Acompanhe os seus.", settings: "Como funciona o salvamento nesta versão." })[view]}</p></div>{view !== "settings" && newTaskButton()}</section>
        <div className={"feedback" + (noticeError ? " feedback-error" : "")} role="status" aria-live="polite">{notice}</div>
        <section className="access-banner" aria-label="Sobre o protótipo"><span className="access-icon"><ShieldCheck size={22} aria-hidden="true" /></span><div><h2>Seu planejamento, sem login</h2><p>Crie suas tarefas e comece a organizar a semana. O acesso fica vinculado a este navegador; apagar os cookies faz você perder esse acesso.</p></div></section>
        {access === "error" && <section className="error-panel" role="alert"><p>Não foi possível carregar suas tarefas. Seus dados não foram alterados.</p><Button variant="outline" onClick={() => void load()}>Tentar novamente</Button></section>}
        {access === "loading" ? <div className="loading-state" role="status"><LoaderCircle className="spin" size={24} />Carregando seu planejamento…</div> : view === "today" ? <>
          <section className="summary-grid" aria-label="Resumo de hoje"><div className="summary-card"><span className="summary-icon lavender"><CalendarDays size={21} /></span><div><span>Para hoje</span><strong>{todayTasks.filter(t => !t.completed).length}<small>tarefas pendentes</small></strong></div></div><div className="summary-card"><span className="summary-icon green"><CheckCheck size={21} /></span><div><span>Seu progresso hoje</span><strong>{todayProgress.done}<small>de {todayProgress.total} concluídas</small></strong></div><Progress value={todayProgress.percent} aria-label="Tarefas concluídas hoje" /></div><div className="summary-card"><span className="summary-icon amber"><ListTodo size={21} /></span><div><span>Para acompanhar</span><strong>{pending.length}<small>tarefas em aberto</small></strong></div></div></section>
          <div className="today-layout"><section className="panel day-timeline"><div className="panel-heading"><div><h2>Sua timeline de hoje</h2><p>{formatDay(today, true)}</p></div><span className="soft-label">{todayTasks.length} {todayTasks.length === 1 ? "atividade" : "atividades"}</span></div><div className="timeline-list">{todayTasks.length ? todayTasks.map(task => <div className="timeline-entry" key={task.id}><time dateTime={task.dueTime ? task.dueDate + "T" + task.dueTime : task.dueDate}>{task.dueTime || "Até 23:59"}</time><span className={"timeline-point" + (task.completed ? " complete" : "")} aria-hidden="true" /><div>{taskItem(task)}</div></div>) : empty("Seu dia pode começar por aqui", "Adicione uma atividade para hoje e encontre seu próximo passo.")}</div></section><aside className="today-aside"><section className="panel next-panel"><div className="section-kicker"><span className="mini-dot" />PRÓXIMO PRAZO</div>{nextTask ? <><h2>{nextTask.title}</h2><p>{nextTask.subject || "Sua atividade"}</p><span className="next-date"><Clock3 size={16} />{formatDay(nextTask.dueDate)}{nextTask.dueTime && " · " + nextTask.dueTime}</span><Button variant="outline" onClick={() => begin(nextTask)}>Ver tarefa<ArrowRight size={16} /></Button></> : <><h2>O próximo passo<br />é seu.</h2><p>Seus próximos prazos aparecem aqui quando você adicionar uma tarefa.</p><Button variant="outline" onClick={() => begin()} disabled={access === "error"}>Começar<ArrowRight size={16} /></Button></>}</section><section className="panel mini-week"><div className="panel-heading"><h2>Visão da semana</h2><button aria-label="Abrir calendário semanal" onClick={() => navigate("calendar")}><ArrowRight size={18} /></button></div><p className="muted small">{anchor && formatWeek(anchor)}</p>{weekPicker()}<div className="mini-week-total"><span>{weekProgress.done} de {weekProgress.total} tarefas concluídas</span><strong>{weekProgress.percent}%</strong></div><Progress value={weekProgress.percent} aria-label="Progresso da semana" /><button className="text-button" onClick={() => navigate("calendar")}>Ver tarefas de {formatDay(selectedDay)}<ArrowRight size={15} /></button></section></aside></div>
        </> : view === "calendar" ? <section className="panel calendar-panel" aria-label="Calendário semanal de entregas"><div className="panel-heading"><div><h2>Calendário semanal</h2><p>{anchor && formatWeek(anchor)}</p></div>{weekControls()}</div>{weekPicker()}<div className="calendar-legend"><span><i className="dot-high" />Alta</span><span><i className="dot-medium" />Média</span><span><i className="dot-low" />Baixa</span><span><i className="done-dot" />Concluída</span></div><div className="selected-day"><div className="panel-heading"><div><h2>{formatDay(selectedDay, true)}</h2><p>Atividades com prazo neste dia</p></div><Button variant="outline" onClick={() => begin(undefined, selectedDay)} disabled={access === "error"}><Plus size={16} />Adicionar neste dia</Button></div>{tasks.some(task => task.dueDate === selectedDay) ? <div className="task-list">{sortTasks(tasks.filter(task => task.dueDate === selectedDay)).map((task: Task) => taskItem(task))}</div> : <div className="day-empty"><CalendarDays size={26} /><h3>Nenhuma entrega neste dia</h3><p>Você pode adicionar uma atividade ou escolher outra data.</p></div>}</div><footer className="panel-footer"><CheckCheck size={17} />{weekProgress.done} de {weekProgress.total} tarefas concluídas nesta semana</footer></section>
        : view === "agenda" ? <section className="panel agenda-panel"><div className="panel-heading"><div><h2>Prazos da semana</h2><p>{anchor && formatWeek(anchor)}</p></div>{weekControls()}</div><p className="scope-note">Esta agenda mostra prazos de tarefas. A distribuição automática de horários ainda não está disponível.</p>{weekTasks.length ? (groupTasksByDay(weekTasks) as [string, Task[]][]).map(([day, items]) => <section className="agenda-day" key={day}><h3>{formatDay(day, true)}{day === today && <span className="soft-label">Hoje</span>}</h3><div className="task-list">{items.map(taskItem)}</div></section>) : empty("Uma semana para organizar", "Adicione suas entregas e acompanhe os prazos em ordem.")}<Button variant="ghost" className="text-button" onClick={() => navigate("tasks")}>Ver tarefas de todas as datas<ArrowRight size={16} /></Button></section>
        : view === "tasks" ? <section className="panel all-tasks"><div className="panel-heading"><div><h2>Suas tarefas <span className="inline-count">{visibleTasks.length}</span></h2><p>Ordenadas por prazo. A prioridade é definida por você.</p></div></div><div className="task-filters">{filterControl("Filtrar por status", status, setStatus, [["all", "Todos os status"], ["pending", "Pendentes"], ["completed", "Concluídas"]])}{filterControl("Filtrar por prioridade", priority, setPriority, [["all", "Todas as prioridades"], ["high", "Prioridade alta"], ["medium", "Prioridade média"], ["low", "Prioridade baixa"]])}{filterControl("Filtrar por disciplina", subject, setSubject, [["all", "Todas as disciplinas"], ...subjects.map(value => [value, value] as [string, string])])}{(query || status !== "all" || priority !== "all" || subject !== "all") && <Button variant="ghost" onClick={() => { setQuery(""); setStatus("all"); setPriority("all"); setSubject("all"); }}>Limpar filtros</Button>}</div>{visibleTasks.length ? <div className="task-list">{visibleTasks.map(taskItem)}</div> : tasks.length ? <div className="day-empty"><Search size={26} /><h3>Nenhuma tarefa encontrada</h3><p>Tente outro termo ou ajuste os filtros.</p></div> : empty()}</section>
        : view === "progress" ? <div className="progress-layout"><section className="panel progress-panel"><div className="panel-heading"><div><h2>Um passo de cada vez</h2><p>Progresso de todas as tarefas cadastradas</p></div><CheckCheck size={24} className="success-icon" /></div><div className="progress-number">{allProgress.percent}<span>%</span></div><Progress value={allProgress.percent} aria-label="Progresso total" /><p>{allProgress.done} de {allProgress.total} tarefas concluídas</p><div className="progress-totals"><div><strong>{allProgress.done}</strong><span>Concluídas</span></div><div><strong>{pending.length}</strong><span>Em aberto</span></div></div></section><section className="panel progress-panel"><div className="panel-heading"><div><h2>Nesta semana</h2><p>{anchor && formatWeek(anchor)}</p></div>{weekControls()}</div><div className="progress-number">{weekProgress.done}<span> / {weekProgress.total}</span></div><Progress value={weekProgress.percent} aria-label="Progresso da semana" /><p>Tarefas com prazo na semana selecionada. Os números refletem o status atual, não um histórico de produtividade.</p><Button variant="outline" onClick={() => navigate("calendar")}>Abrir calendário<ArrowRight size={16} /></Button></section></div>
        : settingsPanel()}
        <footer className="app-footer"><span>Timeline <span aria-hidden="true">·</span> Protótipo acadêmico — PUC-Rio</span><span>Plan today. Move at your pace.</span></footer>
      </main>
    </div>
    <nav className="mobile-navigation" aria-label="Navegação mobile">{([{ id: "today", label: "Hoje", icon: Sun }, { id: "agenda", label: "Agenda", icon: Clock3 }, { id: "add", label: "Adicionar", icon: Plus }, { id: "calendar", label: "Calendário", icon: CalendarDays }, { id: "settings", label: "Ajustes", icon: Settings2 }] as const).map(item => <button key={item.id} className={(item.id === "add" ? "mobile-add " : "") + (view === item.id ? "active" : "")} aria-current={view === item.id ? "page" : undefined} onClick={() => item.id === "add" ? begin() : navigate(item.id)} disabled={item.id === "add" && (access === "loading" || access === "error")}><span><item.icon size={21} /></span>{item.label}</button>)}</nav>
    <Dialog open={open} onOpenChange={value => { if (!saving) setOpen(value); }}><DialogContent className="task-dialog" showCloseButton={false}><DialogHeader><div className="eyebrow">ESPAÇO PARA O PRÓXIMO PASSO</div><DialogTitle>{editing ? "Editar tarefa" : "Adicionar tarefa"}</DialogTitle><DialogDescription>Uma atividade, um prazo. O restante você ajusta no caminho.</DialogDescription></DialogHeader><DialogClose asChild><Button className="dialog-close" variant="ghost" size="icon" disabled={saving} aria-label="Fechar formulário"><X size={18} /></Button></DialogClose><form onSubmit={save} noValidate><div className="form-field"><label htmlFor="task-title">Nome da tarefa <span>*</span></label><Input id="task-title" autoFocus maxLength={120} placeholder="Ex.: Lista de exercícios de Cálculo" value={draft.title} disabled={saving} onChange={event => setDraft({ ...draft, title: event.target.value })} required /></div><div className="form-field"><label htmlFor="task-subject">Disciplina <span className="optional">opcional</span></label><Input id="task-subject" maxLength={60} placeholder="Ex.: Cálculo I" value={draft.subject} disabled={saving} onChange={event => setDraft({ ...draft, subject: event.target.value })} /></div><div className="form-row"><div className="form-field"><label htmlFor="task-date">Data de entrega <span>*</span></label><Input id="task-date" type="date" min="1900-01-01" max="2100-12-31" value={draft.dueDate} disabled={saving} required onChange={event => setDraft({ ...draft, dueDate: event.target.value })} /></div><div className="form-field"><label htmlFor="task-time">Horário <span className="optional">opcional</span></label><Input id="task-time" type="time" value={draft.dueTime} disabled={saving} onChange={event => setDraft({ ...draft, dueTime: event.target.value })} /></div></div><div className="form-field"><label htmlFor="task-priority">Prioridade <span>*</span></label><Select value={draft.priority} onValueChange={value => setDraft({ ...draft, priority: value as Priority })} disabled={saving}><SelectTrigger id="task-priority" className="priority-select"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="high">Alta</SelectItem><SelectItem value="medium">Média</SelectItem><SelectItem value="low">Baixa</SelectItem></SelectContent></Select></div><p className="form-hint">Sem horário definido, o prazo será até o fim do dia. Campos com * são obrigatórios.</p>{formError && <p className="form-error" role="alert">{formError}</p>}<div className="form-actions"><Button type="button" variant="outline" disabled={saving} onClick={() => setOpen(false)}>Cancelar</Button><Button className="primary-button" type="submit" disabled={saving || !canWrite}>{saving ? <LoaderCircle className="spin" size={17} /> : <Check size={17} />}{saving ? "Salvando…" : editing ? "Salvar alterações" : "Salvar tarefa"}</Button></div></form></DialogContent></Dialog>
    <Dialog open={notificationsOpen} onOpenChange={setNotificationsOpen}><DialogContent className="notifications-dialog" showCloseButton={false}><DialogClose asChild><Button variant="ghost" size="icon" className="dialog-close" aria-label="Fechar notificações"><X size={18} /></Button></DialogClose><DialogHeader><span className="empty-icon"><Bell size={24} /></span><DialogTitle>Notificações</DialogTitle><DialogDescription>Os lembretes automáticos ainda não estão disponíveis nesta versão. Você pode acompanhar todos os prazos na agenda.</DialogDescription></DialogHeader><Button variant="outline" onClick={() => { setNotificationsOpen(false); navigate("agenda"); }}>Ver minha agenda<ArrowRight size={16} /></Button></DialogContent></Dialog>
  </SidebarProvider>;
}
