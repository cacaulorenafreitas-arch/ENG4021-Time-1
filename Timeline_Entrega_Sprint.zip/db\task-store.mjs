// Every query is scoped to an owner resolved by the server (legacy account or anonymous browser).

const columns = "id, title, subject, due_date, due_time, priority, category, link, location, notes, reminder, completed, created_at, updated_at";

const mapTask = row => ({
  id: row.id,
  title: row.title,
  subject: row.subject,
  dueDate: row.due_date,
  dueTime: row.due_time,
  priority: row.priority,
  category: row.category,
  link: row.link,
  location: row.location,
  notes: row.notes,
  reminder: row.reminder,
  completed: Boolean(row.completed),
  createdAt: row.created_at,
  updatedAt: row.updated_at,
});

export function taskStore(binding) {
  if (!binding) throw new Error("Task database is unavailable");

  return {
    async list(owner) {
      const result = await binding
        .prepare("SELECT " + columns + " FROM tasks WHERE owner_id = ? ORDER BY due_date, due_time, created_at")
        .bind(owner)
        .all();

      return result.results.map(mapTask);
    },

    async find(owner, id) {
      const row = await binding
        .prepare("SELECT " + columns + " FROM tasks WHERE owner_id = ? AND id = ?")
        .bind(owner, id)
        .first();

      return row ? mapTask(row) : null;
    },

    async create(owner, task) {
      const id = crypto.randomUUID();
      const timestamp = new Date().toISOString();

      await binding
        .prepare(
          "INSERT INTO tasks (id, owner_id, title, subject, due_date, due_time, priority, category, link, location, notes, reminder, completed, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )
        .bind(
          id,
          owner,
          task.title,
          task.subject,
          task.dueDate,
          task.dueTime,
          task.priority,
          task.category,
          task.link,
          task.location,
          task.notes,
          task.reminder,
          0,
          timestamp,
          timestamp
        )
        .run();

      return {
        id,
        ...task,
        completed: false,
        createdAt: timestamp,
        updatedAt: timestamp,
      };
    },

    async update(owner, id, task) {
      const timestamp = new Date().toISOString();

      const result = await binding
        .prepare(
          "UPDATE tasks SET title = ?, subject = ?, due_date = ?, due_time = ?, priority = ?, category = ?, link = ?, location = ?, notes = ?, reminder = ?, completed = ?, updated_at = ? WHERE owner_id = ? AND id = ?"
        )
        .bind(
          task.title,
          task.subject,
          task.dueDate,
          task.dueTime,
          task.priority,
          task.category,
          task.link,
          task.location,
          task.notes,
          task.reminder,
          task.completed ? 1 : 0,
          timestamp,
          owner,
          id
        )
        .run();

      if (result.meta.changes === 0) return null;

      return this.find(owner, id);
    },
  };
}