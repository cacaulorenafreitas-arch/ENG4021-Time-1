import assert from "node:assert/strict";
import test from "node:test";
import { dateKey, validDate, validateTask, weekDays, formatWeek, sortTasks, isOverdue } from "../lib/planner.mjs";

const draft = { title: "Lista de Cálculo", subject: "Cálculo I", dueDate: "2026-09-11", dueTime: "18:00", priority: "high" };
test("U01 — valida tarefa completa e remove espaços extras", () => {
  const result = validateTask({ ...draft, title: "  Lista 3  ", subject: " Cálculo I " });
  assert.equal(result.ok, true); assert.equal(result.value.title, "Lista 3"); assert.equal(result.value.subject, "Cálculo I");
});
test("U02 — rejeita título vazio ou apenas espaços", () => {
  for (const title of ["", "  ", null, 2]) assert.equal(validateTask({ ...draft, title }).ok, false);
});
test("U03 — impõe limites para título e matéria", () => {
  assert.equal(validateTask({ ...draft, title: "a".repeat(121) }).ok, false);
  assert.equal(validateTask({ ...draft, subject: "a".repeat(61) }).ok, false);
  assert.equal(validateTask({ ...draft, title: "a".repeat(120), subject: "a".repeat(60) }).ok, true);
});
test("U04 — rejeita datas inexistentes e formato inválido", () => {
  for (const date of ["2026-02-30", "2026-13-01", "2026-00-12", "11/09/2026", "", "1899-12-31", "2101-01-01"]) assert.equal(validDate(date), false, date);
});
test("U05 — reconhece ano bissexto", () => { assert.equal(validDate("2028-02-29"), true); assert.equal(validDate("2026-02-29"), false); });
test("U06 — exige prioridade alta, média ou baixa", () => {
  for (const priority of ["high", "medium", "low"]) assert.equal(validateTask({ ...draft, priority }).ok, true);
  for (const priority of ["urgent", "", "__proto__", "toString"]) assert.equal(validateTask({ ...draft, priority }).ok, false);
});
test("U07 — valida horários, incluindo meia-noite", () => {
  for (const dueTime of ["", "00:00", "23:59"]) assert.equal(validateTask({ ...draft, dueTime }).ok, true);
  for (const dueTime of ["24:00", "12:60", "9:00", 0]) assert.equal(validateTask({ ...draft, dueTime }).ok, false);
});
test("U08 — matéria e horário são opcionais", () => {
  const result = validateTask({ title: "Estudar", dueDate: "2026-09-10", priority: "low" });
  assert.equal(result.ok, true); assert.equal(result.value.subject, ""); assert.equal(result.value.dueTime, "");
});
test("U09 — semana começa na segunda e termina no domingo", () => {
  assert.deepEqual(weekDays("2026-09-08"), ["2026-09-07", "2026-09-08", "2026-09-09", "2026-09-10", "2026-09-11", "2026-09-12", "2026-09-13"]);
  assert.deepEqual(weekDays("2026-09-13"), weekDays("2026-09-07"));
});
test("U10 — calendário atravessa meses e anos sem perder dias", () => {
  assert.deepEqual(weekDays("2027-01-01"), ["2026-12-28", "2026-12-29", "2026-12-30", "2026-12-31", "2027-01-01", "2027-01-02", "2027-01-03"]);
});
test("U11 — apresenta intervalo da semana em português", () => {
  assert.match(formatWeek("2026-09-08"), /7 de set.*13 de set.*2026/);
  assert.equal(dateKey(new Date(2026, 8, 8, 23)), "2026-09-08");
});
test("U12 — ordena por conclusão, prazo, horário e prioridade", () => {
  const rows = [
    { ...draft, id: "done", completed: true, dueDate: "2026-09-01" },
    { ...draft, id: "low", completed: false, priority: "low" },
    { ...draft, id: "high", completed: false },
    { ...draft, id: "early", completed: false, dueDate: "2026-09-10" },
  ];
  assert.deepEqual(sortTasks(rows).map(t => t.id), ["early", "high", "low", "done"]);
  assert.equal(rows[0].id, "done");
});
test("U13 — identifica atraso a partir do horário local", () => {
  assert.equal(isOverdue({ ...draft, completed: false }, new Date("2026-09-11T18:01:00")), true);
  assert.equal(isOverdue({ ...draft, completed: false }, new Date("2026-09-11T17:59:00")), false);
});
test("U14 — prazo sem horário vale até o final do dia", () => {
  assert.equal(isOverdue({ ...draft, dueTime: "", completed: false }, new Date("2026-09-11T23:59:59")), false);
  assert.equal(isOverdue({ ...draft, dueTime: "", completed: false }, new Date("2026-09-12T00:00:00")), true);
});
test("U15 — tarefa concluída não aparece como atrasada", () => {
  assert.equal(isOverdue({ ...draft, completed: true }, new Date("2026-09-20T12:00:00")), false);
});
