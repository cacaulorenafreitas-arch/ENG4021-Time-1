# Registro de testes — Timeline

Registro mais recente: [Registro_Testes_Sprint.md](Registro_Testes_Sprint.md), de 16/09/2026, com 63 testes automatizados e 17 cenários de interface desktop. As seções abaixo são históricas.

## Atualização — retirada do login (15/09/2026)

**60 testes automatizados aprovados; nenhuma falha, cancelamento ou teste ignorado.** Compilação de produção e verificação TypeScript concluídas com sucesso.

Comandos: `node --test tests/*.test.mjs` e `node_modules/.bin/tsc --noEmit`, após o build de produção pelo fluxo Sites. Saída da execução: [test-results-sem-login.txt](test-results-sem-login.txt). São os 48 testes anteriores, com I17 ampliado para o fluxo sem login do Worker compilado, mais 12 testes G01–G12.

Verificado nesta execução:

- Página pública em português, sem botões de entrar/sair ou perfil de conta.
- Inicialização automática sem conta e cookie HttpOnly, Secure, SameSite=Lax.
- Cadastro, consulta após nova requisição, edição de título/prazo/prioridade, conclusão e reabertura sem login.
- Cookie estável ao recarregar e tarefas preservadas após fechar e reabrir o banco SQLite.
- Isolamento de tarefas entre navegadores e separação dos dados privados da versão anterior.
- Rejeição de gravações sem cookie, cookie inválido/duplicado, origem externa, métodos e formulários inválidos.
- Token de acesso não armazenado em texto no banco; perder o cookie não remove os registros.
- Erro recuperável quando o banco está indisponível, sem apresentar sucesso de salvamento.
- Regressão das regras do calendário semanal, filtros, ordenação e progresso.

Método: requisições HTTP em memória, SQLite isolado com as migrações reais e Worker de produção compilado. Os avisos de banco indisponível correspondem às falhas intencionais de I14 e G10. Não houve gravação de tarefas de teste na produção. Não foram repetidos cliques no navegador nem testes em celular nesta atualização; os testes automatizados não substituem essa verificação.

Roteiro manual pendente para a versão sem login:

1. Abrir o site em uma nova janela e confirmar acesso direto.
2. Criar uma tarefa com prazo e prioridade; conferir na lista e no calendário.
3. Editar título, prazo e prioridade; concluir e reabrir.
4. Atualizar a página e confirmar que a tarefa permanece.
5. Abrir em outro navegador e confirmar que o planejamento começa vazio.
6. Testar formulário, navegação e calendário em celular.

Limites informados na interface: acesso vinculado ao cookie do navegador, sem sincronização entre dispositivos; apagar cookies ou encerrar uma janela anônima faz perder o acesso. Pessoas que compartilham o mesmo navegador compartilham as tarefas. Login foi retirado do escopo, não considerado requisito implementado. Os registros antigos permanecem protegidos.

## Registro histórico — versão com login

O conteúdo abaixo documenta a execução anterior. Os testes manuais e o roteiro autenticado não descrevem a interface atual.

Data: 09/09/2026 (UTC).
Escopo: revisão do Design System, verificação dos casos de uso e regressão das funções da sprint.

## Resultado

**48 testes automatizados aprovados; nenhuma falha e nenhum teste ignorado.**
São 15 testes de regras de tarefas/calendário, 17 de API/persistência/Worker, 12 de busca/filtros/agenda/progresso e 4 de componentes básicos.
Compilação de produção e verificação TypeScript concluídas sem erros.

A saída bruta está em [test-results.tap](test-results.tap).
A avaliação dos requisitos está em [verificacao_casos_de_uso.md](verificacao_casos_de_uso.md).

Os testes aprovados verificam funções implementadas. Eles não significam que os 12 casos de uso completos foram atendidos: **5 permanecem parciais e 7 ausentes**.

## Ambiente e método

- Linux, Node.js 24.19.0, aplicação React/TypeScript e Worker compilado.
- SQLite real isolado, migrações do projeto e adaptador das operações D1.
- Requisições HTTP em memória, sem tocar nos dados do site publicado.
- Chrome em ambiente interno de teste, sessão sem login, área útil de 1348 px de largura.
- O navegador exibiu 08/09 no fuso local; a execução foi registrada em 09/09 UTC. A aplicação usa o fuso do dispositivo.
- Não houve cadastro de alunos, envio de mensagens ou criação de tarefas na produção.

## Testes automatizados

### U01–U15 — Regras de tarefas e calendário

Campos obrigatórios, remoção de espaços extras, limites de texto, datas inválidas, anos bissextos, horários válidos, prioridades, campos opcionais, segunda a domingo, transição de mês/ano, formato em português, ordenação e cálculo de prazo passado.

### I01–I17 — API, persistência e Worker

Identidade obrigatória; lista vazia de nova conta; criação e consulta; edição; conclusão e reabertura; entradas inválidas; JSON e tamanho de requisição; origem externa; isolamento entre contas; proteção do proprietário; consultas parametrizadas; preservação após edição inválida; tarefa inexistente; método não permitido; erro recuperável do banco; índice da consulta; permanência após reabrir o banco; página em português e API do Worker compilado.

O aviso “Task storage operation failed” no log é intencional: I14 simula um banco indisponível.

### T01–T12 — Interface apoiada por regras testáveis

Busca por título e disciplina sem diferenciar acentos/maiúsculas, filtros por status, combinação de filtros, resultado vazio, preservação da entrada, progresso de lista vazia, percentual real, atualização após reabrir, agrupamento por data, agenda vazia e manutenção da ordem horária após concluir uma tarefa.

### Quatro testes de componentes

Utilitários de CSS, semântica acessível da barra de progresso, estilos do componente de gráfico herdado e renderização determinística do componente de carregamento da sidebar. O teste de gráfico não implica presença de gráficos no produto.

## Verificações executadas no navegador

1. **Layout desktop:** logo original, paleta lavanda, menu lateral, resumo e estado vazio inspecionados visualmente. Largura do documento igual à área útil (1348 px), sem rolagem horizontal.
2. **Visitante sem login:** aviso de acesso e link “Entrar com ChatGPT” exibidos; ausência de login não aparece como falha de conexão.
3. **Título obrigatório:** salvar formulário vazio exibiu “Informe uma atividade com até 120 caracteres.”.
4. **Prioridade:** abriu seleção e alterou Média para Alta.
5. **Gravação sem login:** após preencher o título, o salvamento foi bloqueado com “Entre na sua conta para salvar esta tarefa.”; texto digitado preservado.
6. **Cancelar:** fechou o formulário e retornou à tela.
7. **Semana seguinte e Hoje:** mudou de 7–13/09 para 14–20/09 e retornou ao dia atual do navegador.
8. **Data selecionada:** selecionar 16/09 atualizou os detalhes; “Adicionar neste dia” abriu o formulário com 2026-09-16.
9. **Teclado:** Escape fechou o diálogo após a animação; os controles de calendário voltaram a responder.
10. **Busca e filtros:** digitar “calculo” abriu Tarefas; seleção Pendentes funcionou; “Limpar filtros” limpou a busca.
11. **Notificações:** informou que os lembretes não estão disponíveis e o botão abriu Agenda.
12. **Progresso e perfil:** abriu Progresso, confirmou aria-valuenow=0 no estado vazio e abriu Configurações.

Evidência visual: [timeline-desktop.jpg](evidencias/timeline-desktop.jpg).

## Ajustes feitos durante a verificação

- Substituição da identidade PUC Planner pela identidade Timeline.
- Entrada para login em visitas públicas; API continua exigindo identidade protegida.
- Ordenação cronológica da timeline preservada mesmo quando uma tarefa é concluída.
- Próximo prazo exclui tarefas que já passaram do horário de entrega.
- Busca, filtros e progresso usam os mesmos dados das tarefas.
- Avisos claros sobre lembretes e planejamento automático indisponíveis.
- Texto acessível de fechamento de notificações em português.
- Uso de Deep Lavender em botões com texto pequeno para melhorar o contraste.

## Verificações ainda pendentes

- Login real, criação, edição, conclusão e recarga no navegador autenticado. A lógica dessas operações passou nos testes da API, mas isso não substitui o fluxo completo no navegador.
- Teste em celular real, múltiplos navegadores, leitor de tela e navegação completa somente por teclado.
- Teste de carga, latência da produção, auditoria completa de segurança e restauração de backup.
- Teste de usabilidade com alunos reais.

## Roteiro para a apresentação com conta autenticada

- [ ] Entrar e criar “Lista 3 de Cálculo”, com prazo e prioridade alta.
- [ ] Conferir a data no calendário e a disciplina na lista.
- [ ] Editar título, prazo e prioridade; conferir atualização nas duas visualizações.
- [ ] Concluir, verificar progresso e reabrir.
- [ ] Recarregar e confirmar persistência.
- [ ] Experimentar busca/filtros com várias tarefas.
- [ ] Testar navegação e formulário no celular.
- [ ] Registrar dificuldades e sugestões reais dos alunos.

A versão revisada foi preparada para substituir a anterior mediante solicitação de publicação. O envio ao GitHub depende do repositório e do acesso fornecidos pelo grupo.
