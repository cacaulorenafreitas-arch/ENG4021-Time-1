import Timeline from "./timeline";

export const dynamic = "force-dynamic";

export default function Page() {
  return <Timeline />;
}
