ALTER TABLE `tasks` ADD `category` text DEFAULT 'homework' NOT NULL;--> statement-breakpoint
ALTER TABLE `tasks` ADD `link` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `tasks` ADD `location` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `tasks` ADD `notes` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `tasks` ADD `reminder` text DEFAULT 'none' NOT NULL;