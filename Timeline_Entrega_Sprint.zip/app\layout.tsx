import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Timeline | Seu dia, no seu ritmo",
  description: "Plan today. Move at your pace. Organize tarefas, acompanhe seus prazos e visualize a semana com Timeline.",
  icons: { icon: "/brand/timeline-symbol.png", shortcut: "/brand/timeline-symbol.png" },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body className="antialiased">{children}</body></html>;
}
