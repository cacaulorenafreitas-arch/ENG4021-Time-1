import assert from "node:assert/strict";
import test, { after } from "node:test";
import { DatabaseSync } from "node:sqlite";
import { readFileSync, readdirSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { handleTasks } from "../lib/task-api.mjs";
import { handlePrototypeTasks, prototypeCookieName, prototypeSessionPolicy } from "../lib/prototype-api.mjs";

// A SQLite-backed D1 contract adapter. Actual migration SQL is applied, not a mock schema.
function d1(sqlite) {
  return { prepare(sql) {
    const statement = sqlite.prepare(sql);
    return { bind(...values) { return {
      async all() { return { results: statement.all(...values) }; },
      async first() { return statement.get(...values) ?? null; },
      async run() { const result = statement.run(...values); return { meta: { changes: Number(result.changes) } }; },
    }; } };
  } };
}
function migrate(db) {
  for (const file of readdirSync(new URL("../drizzle/", import.meta.url)).filter(name => name.endsWith(".sql")).sort()) {
    db.exec(readFileSync(new URL("../drizzle/" + file, import.meta.url), "utf8"));
  }
  db.exec("PRAGMA optimize");
}
const sqlite = new DatabaseSync(":memory:"); migrate(sqlite); const DB = d1(sqlite);
after(() => sqlite.close());
const draft = { title: "Lista 3 de Cálculo", subject: "Cálculo I", dueDate: "2026-09-11", dueTime: "18:00", priority: "high" };
function request(method, path = "/api/tasks", body, user = "test-student-a", extraHeaders = {}) {
  const headers = { "Content-Type": "application/json", Origin: "https://planner.example", ...extraHeaders };
  if (user) headers["oai-authenticated-user-id"] = user;
  return new Request("https://planner.example" + path, { method, headers, ...(body === undefined ? {} : { body: typeof body === "string" ? body : JSON.stringify(body) }) });
}
async function call(method, path, body, user, extraHeaders) {
  return handleTasks(request(method, path, body, user, extraHeaders), DB);
}
async function create(user = "test-student-a", fields = {}) {
  const response = await call("POST", "/api/tasks", { ...draft, ...fields }, user);
  assert.equal(response.status, 201); return (await response.json()).task;
}
test("I01 — exige identificação da conta", async () => {
  const response = await call("GET", "/api/tasks", undefined, "");
  assert.equal(response.status, 401);
});
test("I02 — nova conta começa sem tarefas", async () => {
  const response = await call("GET", "/api/tasks", undefined, "test-empty");
  assert.deepEqual((await response.json()).tasks, []); assert.equal(response.headers.get("cache-control"), "private, no-store");
});
test("I03 — cria e consulta tarefa persistida", async () => {
  const task = await create("test-create");
  assert.equal(task.completed, false); assert.match(task.id, /^[a-f0-9-]{36}$/);
  const items = (await (await call("GET", "/api/tasks", undefined, "test-create")).json()).tasks;
  assert.equal(items.length, 1); assert.equal(items[0].title, draft.title);
  assert.equal("ownerId" in items[0], false);
});
test("I04 — edita título, prazo, horário e prioridade", async () => {
  const task = await create();
  const response = await call("PATCH", "/api/tasks/" + task.id, { title: "Relatório de Química", dueDate: "2026-09-15", dueTime: "09:30", priority: "low" });
  assert.equal(response.status, 200); const updated = (await response.json()).task;
  assert.equal(updated.title, "Relatório de Química"); assert.equal(updated.dueDate, "2026-09-15"); assert.equal(updated.priority, "low"); assert.equal(updated.dueTime, "09:30");
  assert.equal(updated.id, task.id); assert.equal(updated.createdAt, task.createdAt);
});
test("I05 — conclui e reabre uma tarefa", async () => {
  const task = await create();
  for (const completed of [true, false]) {
    const response = await call("PATCH", "/api/tasks/" + task.id, { completed });
    assert.equal(response.status, 200); assert.equal((await response.json()).task.completed, completed);
  }
});
test("I06 — rejeita entrada inválida sem criar registro", async () => {
  for (const fields of [{ title: " " }, { dueDate: "2026-02-30" }, { priority: "urgent" }]) {
    assert.equal((await call("POST", "/api/tasks", { ...draft, ...fields }, "test-invalid")).status, 400);
  }
  assert.deepEqual((await (await call("GET", "/api/tasks", undefined, "test-invalid")).json()).tasks, []);
});
test("I07 — rejeita JSON inválido, corpo vazio e corpo grande", async () => {
  assert.equal((await call("POST", "/api/tasks", "{")).status, 400);
  assert.equal((await call("POST", "/api/tasks", {})).status, 400);
  assert.equal((await call("POST", "/api/tasks", "a".repeat(9000))).status, 413);
});
test("I08 — rejeita origem externa e tipos de conteúdo incorretos", async () => {
  assert.equal((await call("POST", "/api/tasks", draft, undefined, { Origin: "https://other.example" })).status, 403);
  assert.equal((await call("POST", "/api/tasks", draft, undefined, { "Content-Type": "text/plain" })).status, 415);
});
test("I09 — uma conta não lista nem edita tarefas de outra", async () => {
  const task = await create("test-owner");
  const items = (await (await call("GET", "/api/tasks", undefined, "test-intruder")).json()).tasks;
  assert.equal(items.length, 0);
  assert.equal((await call("PATCH", "/api/tasks/" + task.id, { title: "Alterada" }, "test-intruder")).status, 404);
  assert.equal((await (await call("GET", "/api/tasks", undefined, "test-owner")).json()).tasks[0].title, draft.title);
});
test("I10 — não aceita troca de proprietário nem status inválido", async () => {
  assert.equal((await call("POST", "/api/tasks", { ...draft, ownerId: "test-intruder" })).status, 400);
  const task = await create();
  assert.equal((await call("PATCH", "/api/tasks/" + task.id, { completed: "false" })).status, 400);
});
test("I11 — consultas parametrizadas preservam texto especial", async () => {
  const title = "D'Ávila'); DROP TABLE tasks;--";
  const task = await create("test-quotes", { title });
  assert.equal(task.title, title);
  const items = (await (await call("GET", "/api/tasks", undefined, "test-quotes")).json()).tasks;
  assert.equal(items[0].title, title);
});
test("I12 — edição inválida preserva os dados anteriores", async () => {
  const task = await create("test-preserve");
  assert.equal((await call("PATCH", "/api/tasks/" + task.id, { dueDate: "2026-02-30" }, "test-preserve")).status, 400);
  assert.equal((await (await call("GET", "/api/tasks", undefined, "test-preserve")).json()).tasks[0].dueDate, draft.dueDate);
});
test("I13 — responde corretamente a tarefa inexistente e método não permitido", async () => {
  assert.equal((await call("PATCH", "/api/tasks/00000000-0000-0000-0000-000000000000", { completed: true })).status, 404);
  assert.equal((await call("DELETE", "/api/tasks")).status, 405);
});
test("I14 — indisponibilidade do banco produz erro recuperável", async () => {
  const response = await handleTasks(request("GET"), null);
  assert.equal(response.status, 503); assert.match((await response.json()).error, /Tente novamente/);
});
test("I15 — índice cobre as consultas por proprietário", () => {
  const plan = sqlite.prepare("EXPLAIN QUERY PLAN SELECT id FROM tasks WHERE owner_id = ? ORDER BY due_date").all("test-owner");
  assert.ok(plan.some(row => /idx_tasks_owner_due/.test(row.detail)));
});
test("I16 — dados sobrevivem ao fechamento e à reabertura do banco", async () => {
  const folder = mkdtempSync(join(tmpdir(), "puc-planner-test-"));
  const path = join(folder, "tasks.sqlite");
  let db = new DatabaseSync(path);
  try {
    migrate(db);
    const created = await handleTasks(request("POST", "/api/tasks", draft, "test-persistence"), d1(db));
    assert.equal(created.status, 201);
    db.close(); db = new DatabaseSync(path);
    const reloaded = await handleTasks(request("GET", "/api/tasks", undefined, "test-persistence"), d1(db));
    assert.equal((await reloaded.json()).tasks[0].title, draft.title);
  } finally { db.close(); rmSync(folder, { recursive: true, force: true }); }
});
test("I17 — Worker compilado serve a página em português e encaminha a API", async () => {
  const { default: worker } = await import("../dist/server/index.js");
  const ctx = { waitUntil() {}, passThroughOnException() {} };
  const env = { DB, ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } };
  const htmlResponse = await worker.fetch(new Request("https://planner.example/", { headers: { accept: "text/html" } }), env, ctx);
  assert.equal(htmlResponse.status, 200);
  const html = await htmlResponse.text();
  assert.match(html, /lang="pt-BR"/); assert.match(html, /Seu dia, no seu ritmo/); assert.match(html, /Adicionar tarefa/);
  assert.match(html, /timeline-logo\.png/); assert.match(html, /Navegação principal/);
  assert.doesNotMatch(html, /Starter Project|codex-preview/);
  assert.match(html, /Seu planejamento, sem login/);
  assert.doesNotMatch(html, /Entrar com ChatGPT|Entrar para salvar|Sair da conta|Abrir perfil/);
  const response = await worker.fetch(request("POST", "/api/tasks", draft, "test-built-worker"), env, ctx);
  assert.equal(response.status, 201);
  const result = await worker.fetch(request("GET", "/api/tasks", undefined, "test-built-worker"), env, ctx);
  assert.equal((await result.json()).tasks.length, 1);
  const anonymous = await worker.fetch(guestRequest("GET"), env, ctx);
  assert.equal(anonymous.status, 200);
  const cookie = anonymous.headers.get("set-cookie").split(";")[0];
  const guestCreated = await worker.fetch(guestRequest("POST", cookie, draft), env, ctx);
  assert.equal(guestCreated.status, 201);
  const guestTask = (await guestCreated.json()).task;
  const guestUpdated = await worker.fetch(guestRequest("PATCH", cookie, { completed: true }, "/" + guestTask.id), env, ctx);
  assert.equal((await guestUpdated.json()).task.completed, true);
});

function guestRequest(method, cookie = "", body, suffix = "", extraHeaders = {}) {
  return new Request("https://planner.example/api/prototype/tasks" + suffix, {
    method, headers: { "Content-Type": "application/json", Origin: "https://planner.example", Cookie: cookie, ...extraHeaders },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
}
async function guest(method, cookie, body, suffix, extraHeaders) {
  return handlePrototypeTasks(guestRequest(method, cookie, body, suffix, extraHeaders), DB);
}
async function newBrowser() {
  const response = await guest("GET");
  assert.equal(response.status, 200);
  assert.deepEqual((await response.json()).tasks, []);
  return response.headers.get("set-cookie").split(";")[0];
}

test("G01 — visitante inicia sem conta e recebe cookie protegido", async () => {
  const response = await guest("GET");
  assert.equal(response.status, 200);
  assert.equal(response.headers.get("cache-control"), "private, no-store");
  const cookie = response.headers.get("set-cookie");
  assert.match(cookie, /^__Host-timeline-prototype-v1=[a-f0-9]{64};/);
  for (const flag of ["HttpOnly", "Secure", "SameSite=Lax", "Path=/", "Max-Age=31536000"]) assert.ok(cookie.includes(flag));
  assert.deepEqual(await response.json(), { tasks: [] });
});

test("G02 — cria, recarrega e mantém a mesma sessão sem login", async () => {
  const cookie = await newBrowser();
  const created = await guest("POST", cookie, draft);
  assert.equal(created.status, 201);
  const task = (await created.json()).task;
  const reloaded = await guest("GET", cookie);
  assert.equal(reloaded.headers.get("set-cookie").split(";")[0], cookie);
  assert.deepEqual((await reloaded.json()).tasks, [task]);
});

test("G03 — edita prazo e prioridade, conclui e reabre sem login", async () => {
  const cookie = await newBrowser();
  const task = (await (await guest("POST", cookie, draft)).json()).task;
  const edited = await guest("PATCH", cookie, { title: "Revisar Cálculo", dueDate: "2026-09-20", priority: "low" }, "/" + task.id);
  const updated = (await edited.json()).task;
  assert.equal(edited.status, 200);
  assert.equal(updated.title, "Revisar Cálculo"); assert.equal(updated.dueDate, "2026-09-20"); assert.equal(updated.priority, "low");
  for (const completed of [true, false]) {
    const response = await guest("PATCH", cookie, { completed }, "/" + task.id);
    assert.equal(response.status, 200); assert.equal((await response.json()).task.completed, completed);
  }
});

test("G04 — navegadores diferentes não listam nem alteram tarefas alheias", async () => {
  const owner = await newBrowser(); const other = await newBrowser();
  assert.notEqual(owner, other);
  const task = (await (await guest("POST", owner, draft)).json()).task;
  assert.deepEqual((await (await guest("GET", other)).json()).tasks, []);
  assert.equal((await guest("PATCH", other, { completed: true }, "/" + task.id)).status, 404);
  assert.equal((await (await guest("GET", owner)).json()).tasks[0].completed, false);
});

test("G05 — tarefas antigas da conta continuam privadas e separadas", async () => {
  const legacy = await create("test-legacy-private");
  const cookie = await newBrowser();
  const headers = { "oai-authenticated-user-id": "test-legacy-private" };
  assert.deepEqual((await (await guest("GET", cookie, undefined, "", headers)).json()).tasks, []);
  assert.equal((await guest("PATCH", cookie, { completed: true }, "/" + legacy.id, headers)).status, 404);
  assert.equal((await call("GET", "/api/tasks", undefined, "")).status, 401);
  assert.equal((await (await call("GET", "/api/tasks", undefined, "test-legacy-private")).json()).tasks[0].completed, false);
});

test("G06 — sem cookie não grava nem promete salvamento", async () => {
  const response = await guest("POST", "", draft);
  assert.equal(response.status, 401);
  assert.match((await response.json()).error, /cookies.*formulário foi preservado/);
  assert.equal(response.headers.has("set-cookie"), false);
});

test("G07 — cookie inválido ou duplicado não é usado como proprietário", async () => {
  for (const cookie of [prototypeCookieName + "=test-legacy-private", prototypeCookieName + "=" + "a".repeat(64) + "; " + prototypeCookieName + "=" + "b".repeat(64)]) {
    assert.equal((await guest("POST", cookie, draft)).status, 401);
    const fresh = await guest("GET", cookie);
    assert.equal(fresh.status, 200); assert.deepEqual((await fresh.json()).tasks, []);
  }
});

test("G08 — bloqueia origens externas, gravação sem origem e métodos indevidos", async () => {
  const cookie = await newBrowser();
  assert.equal((await guest("POST", cookie, draft, "", { Origin: "https://other.example" })).status, 403);
  const noOrigin = guestRequest("POST", cookie, draft); noOrigin.headers.delete("Origin");
  assert.equal((await handlePrototypeTasks(noOrigin, DB)).status, 403);
  assert.equal((await guest("GET", cookie, undefined, "", { "Sec-Fetch-Site": "cross-site" })).status, 403);
  assert.equal((await guest("DELETE", cookie)).status, 405);
  assert.equal((await guest("GET", cookie, undefined, "/invalid")).status, 404);
});

test("G09 — valida formulário e não permite alterar proprietário", async () => {
  const cookie = await newBrowser();
  for (const fields of [{ title: " " }, { dueDate: "2026-02-30" }, { priority: "urgent" }, { ownerId: "test-legacy-private" }]) {
    assert.equal((await guest("POST", cookie, { ...draft, ...fields })).status, 400);
  }
  assert.deepEqual((await (await guest("GET", cookie)).json()).tasks, []);
});

test("G10 — banco indisponível retorna erro sem criar nova sessão", async () => {
  const response = await handlePrototypeTasks(guestRequest("GET"), null);
  assert.equal(response.status, 503); assert.equal(response.headers.has("set-cookie"), false);
});

test("G11 — token não aparece no banco e perder o cookie não apaga tarefas", async () => {
  const cookie = await newBrowser();
  const task = (await (await guest("POST", cookie, draft)).json()).task;
  const row = sqlite.prepare("SELECT owner_id FROM tasks WHERE id = ?").get(task.id);
  assert.match(row.owner_id, /^prototype-browser:[a-f0-9]{64}$/);
  assert.ok(!row.owner_id.includes(cookie.split("=")[1]));
  const fresh = await guest("GET"); assert.deepEqual((await fresh.json()).tasks, []);
  assert.equal((await (await guest("GET", cookie)).json()).tasks[0].id, task.id);
});

test("G12 — tarefas sem login persistem após reabrir o banco", async () => {
  const folder = mkdtempSync(join(tmpdir(), "timeline-guest-test-"));
  const path = join(folder, "tasks.sqlite"); let db = new DatabaseSync(path);
  try {
    migrate(db);
    const session = await handlePrototypeTasks(guestRequest("GET"), d1(db));
    const cookie = session.headers.get("set-cookie").split(";")[0];
    const created = await handlePrototypeTasks(guestRequest("POST", cookie, draft), d1(db));
    assert.equal(created.status, 201);
    db.close(); db = new DatabaseSync(path);
    const response = await handlePrototypeTasks(guestRequest("GET", cookie), d1(db));
    assert.equal((await response.json()).tasks[0].title, draft.title);
  } finally { db.close(); rmSync(folder, { recursive: true, force: true }); }
});

test("G13 — produção sempre mantém o cookie seguro, inclusive no host de teste", () => {
  for (const origin of ["https://planner.example", "http://terminal.local:4173"]) {
    const policy = prototypeSessionPolicy(new URL(origin));
    assert.equal(policy.cookieName, prototypeCookieName); assert.equal(policy.secure, true);
    assert.equal(policy.namespace, "prototype-browser:");
  }
});

test("G14 — cookie de teste só existe no desenvolvimento e no host exato", () => {
  const preview = prototypeSessionPolicy(new URL("http://terminal.local:4173"), true);
  assert.equal(preview.cookieName, "timeline-preview-v1"); assert.equal(preview.secure, false);
  assert.equal(preview.namespace, "prototype-preview:");
  for (const origin of ["https://planner.example", "http://example.com", "http://terminal.local:4174"]) {
    assert.equal(prototypeSessionPolicy(new URL(origin), true).secure, true);
  }
});

test("G15 — a API de produção ignora o cookie separado do ambiente de teste", async () => {
  const response = await guest("POST", "timeline-preview-v1=" + "a".repeat(64), draft);
  assert.equal(response.status, 401);
});
